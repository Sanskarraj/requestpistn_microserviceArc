package dart










import 'dart:math';

class Pair<K, V> {
  final K key;
  final V value;

  Pair(this.key, this.value);
}

List<int> twoSum(List<int> nums, int target) {
  Map<int, int> numMap = {};
  for (int i = 0; i < nums.length; i++) {
    int complement = target - nums[i];
    if (numMap.containsKey(complement)) {
      return [numMap[complement]!, i];
    }
    numMap[nums[i]] = i;
  }
  return [];
}

Pair<double, int> calculateComplexity(List<int> nums, int target) {
  int startTime = DateTime.now().microsecondsSinceEpoch;
  List<int> result = twoSum(nums, target);
  int endTime = DateTime.now().microsecondsSinceEpoch;
  double timeComplexity = (endTime - startTime) / 1000; // convert to milliseconds
  // Space complexity (in bytes)
  int spaceComplexity = (4 * nums.length) + (4 * nums.length) + (nums.length * 32); // Approximate size of Map
  return Pair(timeComplexity, spaceComplexity);
}

void main() {
  List<List<int>> nums = [
    [2, 7, 11, 15],
    [3, 2, 4],
    [1, 5, 5],
    [1, 2, 3, 4, 5],
    [5, 3, 5, 7]
  ];
  List<int> targets = [9, 6, 10, 9, 10];
  List<List<int>> results = [];
  List<Pair<double, int>> complexities = [];

  for (int i = 0; i < nums.length; i++) {
    int target = targets[i];
    Pair<double, int> complexity = calculateComplexity(nums[i], target);
    complexities.add(complexity);
    List<int> result = twoSum(nums[i], target);
    results.add(result);
    print("Test case ${i + 1}:");
    print("Input: num = [${nums[i].join(',')}], target = $target");
    print("Output: [${result.join(',')}]");
    print("Time complexity: ${complexity.key.toStringAsFixed(6)} ms");
    print("Space complexity: ${complexity.value} bytes\n");
  }
}