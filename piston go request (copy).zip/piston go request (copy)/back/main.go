package main

import (
	// "bytes"
	"encoding/json"
	"fmt"
	// "net/http"
	// "strings"
	"log"
	"encoding/base64"
	// "strconv"

)

// type File struct {
// 	Name    string `json:"name"`
// 	Content string `json:"content"`
// }

type TestCase struct {
	Input   [][]int `json:"input"`
	Targets []int   `json:"targets"`
}

// type ExecuteRequest struct {
// 	Language           string   `json:"language"`
// 	Version            string   `json:"version"`
// 	Files              []File   `json:"files"`
// 	Stdin              string   `json:"stdin"`
// 	Args               []string `json:"args"`
// 	CompileTimeout     int      `json:"compile_timeout"`
// 	RunTimeout         int      `json:"run_timeout"`
// 	CompileMemoryLimit int      `json:"compile_memory_limit"`
// 	RunMemoryLimit     int      `json:"run_memory_limit"`
// }





func main() {


	// mapLanguage := map[int]string{
	// 	111: "c++",
	// 	121: "java",
	// 	131: "c",
	// 	141: "python",
	// 	151: "javascript",
	// 	161: "go",
	// 	173: "rust",
	// 	183: "swift",
	// 	193: "kotlin",
	// 	177: "ruby",
	// 	187: "typescript",
	// 	191: "csharp",
	// 	197: "dart",
	// };


	// mapVersion := map[int]string{
	// 	111: "10.2.0",
	// 	121: "15.0.2",
	// 	131: "10.2.0",
	// 	141: "3.12.0",
	// 	151: "20.11.1",
	// 	161: "1.16.2",
	// 	173: "1.68.2",
	// 	183: "5.3.3",
	// 	193: "1.8.20",
	// 	177: "3.0.1",
	// 	187: "5.0.3",
	// 	191: "5.0.201",
	// 	197: "2.19.6",
	// };


	// mapExtensions := map[int]string{
	// 	111: ".cpp",
	// 	121: ".java",
	// 	131: ".cpp",
	// 	141: ".py",
	// 	151: ".js",
	// 	161: ".go",
	// 	173: ".rs",
	// 	183: ".swift",
	// 	193: ".kt",
	// 	177: ".rb",
	// 	187: ".ts",
	// 	191: ".cs",
	// 	197: ".dart",
	// };
	
	



	// coming from cassandra db datastax 
	// select sample_testcase/all_testcase from test.testcases;


	// originalJSON := `{
	// 	"input": [
	// 	  [2, 7, 11, 15, 20, 30, 40, 50, 60, 80, 90, 100, 120, 130, 140, 150],
	// 	  [3, 2, 4, 8, 16, 23, 42, 58, 71, 84, 99, 101, 113, 127, 135, 149, 160],
	// 	  [1, 5, 5, 2, 9, 14, 28, 33, 41, 56, 73, 89, 100, 105, 117, 124, 137, 141]
	// 	],
	// 	"targets": [220, 236, 200]
	//   }`


	base64String := "ew0KImlucHV0IjogWw0KCQkgIFsyLCA3LCAxMSwgMTUsIDIwLCAzMCwgNDAsIDUwLCA2MCwgODAsIDkwLCAxMDAsIDEyMCwgMTMwLCAxNDAsIDE1MF0sDQoJCSAgWzMsIDIsIDQsIDgsIDE2LCAyMywgNDIsIDU4LCA3MSwgODQsIDk5LCAxMDEsIDExMywgMTI3LCAxMzUsIDE0OSwgMTYwXSwNCgkJICBbMSwgNSwgNSwgMiwgOSwgMTQsIDI4LCAzMywgNDEsIDU2LCA3MywgODksIDEwMCwgMTA1LCAxMTcsIDEyNCwgMTM3LCAxNDFdDQpdLA0KInRhcmdldHMiOiBbMjIwLCAyMzYsIDIwMF0NCn0="
	// language_id:=111
	// function_code :=""

	// Decode Base64 string
	decodedBytes, err := base64.StdEncoding.DecodeString(base64String)
	if err != nil {
		fmt.Println("Error decoding Base64 string:", err)
		return
	}

	// Convert decoded bytes to string (JSON)
	originalJSON := string(decodedBytes)
	fmt.Println("Decoded JSON:", originalJSON)




	var testCase TestCase
	err = json.Unmarshal([]byte(originalJSON), &testCase)
	if err != nil {
		log.Fatalf("Error unmarshalling JSON: %v", err)
	}

	// Marshal the `input` part back into JSON
	Input1, err := json.Marshal(testCase.Input)
	if err != nil {
		log.Fatalf("Error marshalling input to JSON: %v", err)
	}

	// Marshal the `targets` part back into JSON
	Input2, err := json.Marshal(testCase.Targets)
	if err != nil {
		log.Fatalf("Error marshalling targets to JSON: %v", err)
	}
	
    jsonInput1 := string(Input1)
	jsonInput2 := string(Input2)
	
fmt.Println("jsonInput1",jsonInput1)
fmt.Println("jsonInput2",jsonInput2)



 
// 	language := mapLanguage[language_id]
// // 	//language mapper 



// 	version := mapVersion[language_id]
// 	//version mapper

// 	name :="index"+mapExtensions[language_id]


// 	code := 
        
	//switch code

	// Initialize args (if needed)
// 	args := []string{}

// 	// Create the JSON request payload
// 	requestPayload := ExecuteRequest{
// 		Language:           language,
// 		Version:            version,
// 		Files:              []File{{Name: name, Content: code}},
// 		Stdin:              "",
// 		Args:               args,
// 		CompileTimeout:     10000,
// 		RunTimeout:         3000,
// 		CompileMemoryLimit: -1,
// 		RunMemoryLimit:     -1,
// 	}

// 	// Convert to JSON
// 	jsonData, err := json.Marshal(requestPayload)
// 	if err != nil {
// 		fmt.Println("Error marshalling JSON:", err)
// 		return
// 	}

// 	// Print the JSON payload
// 	fmt.Println("Generated JSON:")
// 	fmt.Println(string(jsonData))

// 	// Send the POST request
// 	resp, err := http.Post("http://localhost:2000/api/v2/execute", "application/json", bytes.NewBuffer(jsonData))
// 	if err != nil {
// 		fmt.Println("Error sending request:", err)
// 		return
// 	}
// 	defer resp.Body.Close()

// 	// Read the response
// 	var responseBody bytes.Buffer
// 	responseBody.ReadFrom(resp.Body)
// 	fmt.Println("Response from server:")
// 	fmt.Println(responseBody.String())
// }


}

// func codeSwitcher (id int , json1 string , json2 string, function_code string) string{
// 	s :=""

// 	switch {
// 	case id == 111:
// 		s= 
// 	case id == 121:
// 		s= 
// 	case id == 131:
// 		s= 
// 	case id == 141:
// 		s= 
// 	case id == 151:
// 		s= 
// 	case id == 161:
// 		s= 
// 	case id == 173:
// 		s= 
// 	case id == 183:
// 		s= 
// 	case id == 193:
// 		s= 
// 	case id == 177:
// 		s= 
// 	case id == 187:
// 		s= 
// 	case id == 191:
// 		s= 
// 	case id == 197:
// 		s= 
// 	// default:
// 	// 	s=""

// 	return s; 
// 	}
// }