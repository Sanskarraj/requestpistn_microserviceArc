package typescript


type Pair<K, V> = {
    key: K;
    value: V;
};

function twoSum(nums: number[], target: number): number[] {
    const numMap: { [key: number]: number } = {};
    for (let i = 0; i < nums.length; i++) {
        const complement: number = target - nums[i];
        if (complement in numMap) {
            return [numMap[complement], i];
        }
        numMap[nums[i]] = i;
    }
    return [];
}

function calculateComplexity(nums: number[], target: number): Pair<number, number> {
    const startTime: number = performance.now();
    
    const result: number[] = twoSum(nums, target);
    
    const endTime: number = performance.now();
    const timeComplexity: number = endTime - startTime; // in milliseconds
    
    // Space complexity (in bytes)
    const spaceComplexity: number = (4 * nums.length) + (4 * nums.length) + (nums.length * 32); // Approximate size of the object
    
    return { key: timeComplexity, value: spaceComplexity };
}

const numsList: number[][] = [
    [2, 7, 11, 15],
    [3, 2, 4],
    [1, 5, 5],
    [1, 2, 3, 4, 5],
    [5, 3, 5, 7]
];
const targets: number[] = [9, 6, 10, 9, 10];

for (let i = 0; i < numsList.length; i++) {
    const nums: number[] = numsList[i];
    const target: number = targets[i];
    
    const complexity: Pair<number, number> = calculateComplexity(nums, target);
    
    const result: number[] = twoSum(nums, target);
    
    console.log("Test case " + (i + 1) + ":");
    console.log("Input: num = [" + nums.join(',') + "]");
    console.log("target = " + target);
    console.log("Output: [" + result.join(',') + "]");
    console.log("Time complexity: " + complexity.key + " ms");
    console.log("Space complexity: " + complexity.value + " bytes\n");
}