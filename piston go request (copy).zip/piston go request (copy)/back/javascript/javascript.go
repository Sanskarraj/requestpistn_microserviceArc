package javascript


function twoSum(nums, target) {
    const numMap = new Map();
    for (let i = 0; i < nums.length; i++) {
        const complement = target - nums[i];
        if (numMap.has(complement)) {
            return [numMap.get(complement), i];
        }
        numMap.set(nums[i], i);
    }
    return [];
}

function calculateComplexity(nums, target) {
    const startTime = performance.now();
    
    // Execute twoSum here for time complexity measurement
    const result = twoSum(nums, target);
    
    const endTime = performance.now();
    const timeComplexity = endTime - startTime; // time in milliseconds
    
    // Approximate space complexity in bytes
    const spaceComplexity = (4 * nums.length) + (4 * nums.length) + (nums.length * 32); // Approximate size of Map
    
    // Return an object containing time complexity, space complexity, and result
    return {
        timeComplexity: timeComplexity,
        spaceComplexity: spaceComplexity,
        result: result
    };
}

function printResults(numsList, targets) {
    numsList.forEach(function(nums, index) {
        var target = targets[index];
        
        // Get the result and complexity in one step
        var resultData = calculateComplexity(nums, target);
        var timeComplexity = resultData.timeComplexity;
        var spaceComplexity = resultData.spaceComplexity;
        var result = resultData.result;
        
        console.log('Test case ' + (index + 1) + ':');
        console.log('Input: num = [' + nums.join(',') + '], target = ' + target);
        console.log('Output: [' + result.join(',') + ']');
        console.log('Time complexity: ' + timeComplexity.toFixed(6) + ' ms');
        console.log('Space complexity: ' + spaceComplexity + ' bytes\n');
    });
}


// Test cases
// json unrmarshalling - > direclty feed the string of inputjson1 to this they give the same format string datatype no need for additional functions
const numsList = [
    [2, 7, 11, 15],
    [3, 2, 4],
    [1, 5, 5],
    [1, 2, 3, 4, 5],
    [5, 3, 5, 7]
];
const targets = [9, 6, 10, 9, 10];

printResults(numsList, targets);
