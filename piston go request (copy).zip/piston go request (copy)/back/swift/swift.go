package swift



import Foundation

class TwoSum {
    static func twoSum(_ nums: [Int], _ target: Int) -> [Int] {
        var numMap = [Int: Int]()
        for i in 0..<nums.count {
            let complement = target - nums[i]
            if let complementIndex = numMap[complement] {
                return [complementIndex, i]
            }
            numMap[nums[i]] = i
        }
        return []
    }
    
    // Function to calculate time and space complexity
    static func calculateComplexity(_ nums: [Int], _ target: Int) -> (Double, Int) {
        let startTime = DispatchTime.now()
        
        let _ = twoSum(nums, target)
        
        let endTime = DispatchTime.now()
        let timeComplexity = Double(endTime.uptimeNanoseconds - startTime.uptimeNanoseconds) / 1_000_000 // convert to milliseconds
        
        // Space complexity (in bytes)
        let spaceComplexity = MemoryLayout<Int>.size * nums.count * 2 + nums.count * 32 // Approximate size of Dictionary
        
        return (timeComplexity, spaceComplexity)
    }
    
    static func main() {
        let nums = [
            [2, 7, 11, 15],
            [3, 2, 4],
            [1, 5, 5],
            [1, 2, 3, 4, 5],
            [5, 3, 5, 7]
        ]
        let targets = [9, 6, 10, 9, 10]
        
        var results = [[Int]]()
        var complexities = [(Double, Int)]()
        
        for i in 0..<nums.count {
            let target = targets[i]
            let complexity = calculateComplexity(nums[i], target)
            complexities.append(complexity)
            
            let result = twoSum(nums[i], target)
            results.append(result)
            
            print("Test case \(i + 1):")
            print("Input: num = [", terminator: "")
            for j in 0..<nums[i].count {
                print(nums[i][j], terminator: j < nums[i].count - 1 ? "," : "")
            }
            print("], target = \(target)")
            
            print("Output: [", terminator: "")
            for j in 0..<result.count {
                print(result[j], terminator: j < result.count - 1 ? "," : "")
            }
            print("]")
            
            print("Time complexity: \(complexity.0) ms")
            print("Space complexity: \(complexity.1) bytes\n")
        }
    }
}

// Run the main function
TwoSum.main()
