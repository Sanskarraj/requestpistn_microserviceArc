package main

import (
    "container/heap"
    "container/list"
    "errors"
    "fmt"
    "math"
    "math/rand"
    "sort"
    "strconv"
    "strings"
    "sync"
    "time"
)

func twoSum(nums []int, target int) []int {
    numMap := make(map[int]int)
    for i, num := range nums {
        complement := target - num
        if idx, found := numMap[complement]; found {
            return []int{idx, i}
        }
        numMap[num] = i
    }
    return []int{}
}

func calculateComplexity(nums []int, target int) (float64, int64) {
    start := time.Now()
    
    twoSum(nums, target)
    
    elapsed := time.Since(start)
    timeComplexity := float64(elapsed.Nanoseconds()) / 1e6 // Convert nanoseconds to milliseconds
    
    // Space complexity (in bytes)
    spaceComplexity := int64(len(nums)*8 + len(nums)*8 + 24) // Approximate size of map
    
    return timeComplexity, spaceComplexity
}

func main() {
    // Usage of unused imports:
    _ = heap.Interface(nil)       // Minimal usage of container/heap
    _ = list.New()                // Minimal usage of container/list
    _ = errors.New("sample error") // Minimal usage of errors
    _ = math.Pi                   // Minimal usage of math
    _ = rand.Intn(10)             // Minimal usage of math/rand
    _ = sort.Ints([]int{1})       // Minimal usage of sort
    _ = strconv.Itoa(10)          // Minimal usage of strconv
    _ = strings.Contains("abc", "a") // Minimal usage of strings
    _ = sync.Mutex{}              // Minimal usage of sync
    _ = time.Now()                // Minimal usage of time

    numsList := [][]int{
        {2, 7, 11, 15},
        {3, 2, 4},
        {1, 5, 5},
        {1, 2, 3, 4, 5},
        {5, 3, 5, 7},
    }
    targets := []int{9, 6, 10, 9, 10}

    for i := 0; i < len(numsList); i++ {
        target := targets[i]
        timeComplexity, spaceComplexity := calculateComplexity(numsList[i], target)
        
        result := twoSum(numsList[i], target)
        
        fmt.Printf("Test case %d:\n", i+1)
        fmt.Printf("Input: nums = %v, target = %d\n", numsList[i], target)
        fmt.Printf("Output: %v\n", result)
        fmt.Printf("Time complexity: %.6f ms\n", timeComplexity)
        fmt.Printf("Space complexity: %d bytes\n\n", spaceComplexity)
    }
}
