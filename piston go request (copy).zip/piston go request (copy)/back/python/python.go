package python


import time
import sys

def two_sum(nums, target):
    num_map = {}
    for i, num in enumerate(nums):
        complement = target - num
        if complement in num_map:
            return [num_map[complement], i]
        num_map[num] = i
    return []

def calculate_complexity(nums, target):
    start_time = time.time()
    
    result = two_sum(nums, target)
    
    end_time = time.time()
    time_complexity = (end_time - start_time) * 1000  # Convert to milliseconds
    
    # Space complexity (in bytes)
    space_complexity = sys.getsizeof(nums) + sys.getsizeof({}) + len(nums) * sys.getsizeof(int())  # Approximate size of list and dict
    
    return time_complexity, space_complexity

def main():


// json unrmarshalling - > direclty feed the string of inputjson1 to this they give the same format string datatype no need for additional functions


    nums_list = [
        [2, 7, 11, 15],
        [3, 2, 4],
        [1, 5, 5],
        [1, 2, 3, 4, 5],
        [5, 3, 5, 7]
    ]
    targets = [9, 6, 10, 9, 10]

    for i, nums in enumerate(nums_list):
        target = targets[i]
        complexity = calculate_complexity(nums, target)
        
        result = two_sum(nums, target)
        
        print(f"Test case {i + 1}:")
        print(f"Input: num = [{', '.join(map(str, nums))}], target = {target}")
        
        print(f"Output: [{', '.join(map(str, result))}]")
        
        print(f"Time complexity: {complexity[0]:.5f} ms")
        print(f"Space complexity: {complexity[1]} bytes\n")

if __name__ == "__main__":
    main()